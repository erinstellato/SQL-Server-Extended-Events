/*============================================================================
  File:     2a_tsql_stack_research.sql

  SQL Server Versions: 2012 onwards
------------------------------------------------------------------------------
  Written by Jonathan Kehayias, SQLskills.com
  Modified by Erin Stellato, SQLskills.com
  
  (c) 2020, SQLskills.com. All rights reserved.

  For more scripts and sample code, check out 
    http://www.SQLskills.com

  You may alter this code for your own *non-commercial* purposes. You may
  republish altered code as long as you include this copyright and give due
  credit, but you must obtain prior permission before blogging this code.
  
  THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF 
  ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED 
  TO THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
  PARTICULAR PURPOSE.
============================================================================*/
/*
	Restore database
	*you may need to change the backup
	and restore locations
*/
USE [master]
GO

RESTORE DATABASE [WideWorldImporters] 
	FROM  DISK = N'C:\Backups\WWI_Expanded.bak' WITH  FILE = 1,  
	MOVE N'WWI_Primary' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.mdf',  
	MOVE N'WWI_UserData' TO N'C:\Databases\WideWorldImporters\WideWorldImporters_UserData.ndf',  
	MOVE N'WWI_Log' TO N'C:\Databases\WideWorldImporters\WideWorldImporters.ldf',  
	NOUNLOAD,  REPLACE,  STATS = 5

GO

USE [WideWorldImporters];
GO

/*
	Create a function so we can track its usage
	(just returns a value when it executes)
*/
CREATE FUNCTION [dbo].[ReturnsTrue]
(@TestValue INT)
RETURNS NVARCHAR(20)
AS
BEGIN
	DECLARE @RetVal NVARCHAR(20) = 'Fxn Called by Third';
	RETURN(@RetVal);
END
GO

/*
	Create the last procedure in the nested calls
*/
CREATE PROCEDURE [dbo].[CalledThird] (@input int)
AS 
BEGIN
	IF (@input = 100)
	BEGIN
		SELECT 'Third was called, just returns text';
	END
	ELSE 
	BEGIN
		SELECT dbo.ReturnsTrue(@input);
	END
END
GO

/*
	Create the second procedure in the nested calls
*/
CREATE PROCEDURE [dbo].[CalledSecond]
AS 
BEGIN
	EXECUTE dbo.CalledThird 1;
END

GO

/*
	Create the first procedure in the nested calls
*/
CREATE PROCEDURE [dbo].[CalledFirst]
AS 
BEGIN
	EXECUTE [dbo].[CalledSecond];
END
GO

/*
	Create another first procedure that doesn't nest as far.
*/
CREATE PROCEDURE [dbo].[OtherProcedure]
AS 
BEGIN
	
	/* Don't cause the function to be called */
	EXECUTE dbo.CalledThird 100;
	
	/* Cause the function to be called */
	EXECUTE dbo.CalledThird 1;
END
GO